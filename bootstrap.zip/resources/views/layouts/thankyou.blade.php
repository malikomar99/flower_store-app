@extends('layouts.app')

@section('contents')

<h1>submit order successfully</h1>
@endsection