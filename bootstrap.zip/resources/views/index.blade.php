@extends('layouts.app')
<x-adminnavbar/>

@section('content')
<div class="container">
  @if(Session::has('massage'))
  <div class="alert alert-success">
    {{session::get('massage')}}
  </div>
    
  @endif
 
    <div class="row">
        @foreach ($data as $pro )
        <div class="col-md-3">
            <div class="card">
                <img src="{{$pro->images}}" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">{{$pro->title}} </h5>
                  <p class="card-text">{{$pro->description}}</p>
                  <p class="card-text">price:{{$pro->price}}</p>
                  <p class="card-text">quantity:{{$pro->quantity}}</p>
                  
                  <a href="{{route('product-details',['id'=>$pro->id])}}" class="btn btn-primary">view details </a>
                   <a href="{{route('checkout')}}" class="btn btn-primary">Buy Now </a>
                  {{-- <a href="{{env('APP_URL')}}/product/{{$pro->id}}" class="btn btn-primary">view details </a> --}}
                  {{-- <a href="{{route('addtocart',['id'=>$pro->id])}}" class="btn btn-primary">add to cart </a> --}}

                </div>
              </div>
        </div>
            
        @endforeach
    </div>
</div>

@endsection




