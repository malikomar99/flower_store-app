
@extends('layouts.app')

@section('content')
<section class="h-100" style="background-color: #f0eeee;">
    <div class="container h-100 py-5">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-10">
            @if (Session::has('massage'))
            <div class="alert alert-danger">
               {{Session::get('massage')}} 
            </div>
                
            @endif
  
          <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-normal mb-0 text-black">Shopping Cart</h3>
            <div>
              <p class="mb-0"><span class="text-muted">Sort by:</span> <a href="#!" class="text-body">price <i
                    class="fas fa-angle-down mt-1"></i></a></p>
            </div>
          </div>
  
          
  
         @if (Session::has('cart'))
         @php $total = 0; @endphp
         @foreach (Session::get('cart') as $cart )
               <div class="card rounded-3 mb-4">
            <div class="card-body p-4">
              <div class="row d-flex justify-content-between align-items-center">
                <div class="col-md-2 col-lg-2 col-xl-2">
                  <img
                  src="{{$cart['images']}}"

                    class="img-fluid rounded-3" alt="Cotton T-shirt">
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3">
                  <p class="lead fw-normal mb-2">{{$cart['title']}}</p>
                  <p><span class="text-muted">price:{{$cart['price']}} </span></p>
                  <p><span class="text-muted">quantity:{{$cart['quantity']}} </span></p>
                </div>
                
                <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                  <h5 class="mb-0">total:{{$cart['price'] * $cart['quantity']}}</h5>
                </div>
                <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                  <h5 class="mb-0"></h5>
                </div>
                <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                  <a onclick="return confirm('Are you sure to remove cart')" href="{{route('removeitems', ['id'=>$cart['id']])}}" class="btn btn-danger">remove<i class="fas fa-trash fa-lg"></i></a>
                </div>
               
              </div>
            </div>

          </div>
          
          @endforeach
          @else
          <div class="alert alert-info">
            no items in your cart
          </div>

          @endif
         
          <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
            <p class="mb-0"> Total Amount: </p>
          </div>
          <div class="card">
            <div class="card-body">
                <a href="{{route('checkout')}}" class="btn btn-primary">checkout </a>
            </div>
          </div>
  
        </div>
      </div>
    </div>
  </section>
@endsection