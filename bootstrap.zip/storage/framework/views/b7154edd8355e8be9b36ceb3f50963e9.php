<?php $show_menu = false; ?>

<!------ Include the above in your HEAD tag ---------->
<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<div class="card">
			<div class="container-fliud">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="<?php echo e($pro->images); ?>" ></div>
						  
						</div>
						<ul class="preview-thumbnail nav nav-tabs">
						  <li class="active"><a data-target="#pic-1" data-toggle="tab"><img src="<?php echo e($pro->images); ?>" class="card-img-top" alt="..."></a></li>
						  
						</ul>
						
					</div>
					<div class="details col-md-6">
						<h3 class="product-title"><?php echo e($pro->title); ?> </h3>
						<div class="rating">
							<div class="stars">
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<span class="review-no">41 reviews</span>
						</div>
						<p class="product-description"> <?php echo e($pro->description); ?></p>
						<h4 class="price">current price: <span><?php echo e($pro->price); ?></span></h4>
						<p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
						
						
						<div class="block quantity">
                  <input type="number" class="form-control btn btn-outline-dark rounded-3"
                      id="cart_quantity" value="1" min="1" max="<?php echo e($pro->quantity); ?>" name="cart_quantity">
              </div>
						<div class="action">
                            <a href="<?php echo e(route('checkout',['id' => $pro->id])); ?>" 
                                class="shadow btn custom-btn ">Buy Now</a>
								<a href="<?php echo e(route('addtocart',['id' => $pro->id])); ?>" 
                        class="shadow btn custom-btn ">Add to Cart</a>
						</div>
					</div>
				</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<script>
	let av_qty = <?php echo e($pro->quantity); ?>;
	cart_quantity.onchange = () => {
		if(cart_quantity.value > av_qty){
			alert("You can't add more than <?php echo e($pro->quantity); ?> items");
			cart_quantity.value = av_qty;
		}
	}
  </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/productdetails.blade.php ENDPATH**/ ?>