<?php $__env->startSection('content'); ?>
<section class="h-100" style="background-color: #f0eeee;">
    <div class="container h-100 py-5">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-10">
            <?php if(Session::has('massage')): ?>
            <div class="alert alert-danger">
               <?php echo e(Session::get('massage')); ?> 
            </div>
                
            <?php endif; ?>
  
          <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-normal mb-0 text-black">Shopping Cart</h3>
            <div>
              <p class="mb-0"><span class="text-muted">Sort by:</span> <a href="#!" class="text-body">price <i
                    class="fas fa-angle-down mt-1"></i></a></p>
            </div>
          </div>
  
          
  
         <?php if(Session::has('cart')): ?>
         <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="card rounded-3 mb-4">
            <div class="card-body p-4">
              <div class="row d-flex justify-content-between align-items-center">
                <div class="col-md-2 col-lg-2 col-xl-2">
                  <img
                  src="<?php echo e($cart['images']); ?>"

                    class="img-fluid rounded-3" alt="Cotton T-shirt">
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3">
                  <p class="lead fw-normal mb-2"><?php echo e($cart['title']); ?></p>
                  <p><span class="text-muted">price:<?php echo e($cart['price']); ?> </span></p>
                  <p><span class="text-muted">quantity:<?php echo e($cart['quantity']); ?> </span></p>
                </div>
                
                <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                  <h5 class="mb-0">total:<?php echo e($cart['price'] * $cart['quantity']); ?></h5>
                </div>
                <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                  <h5 class="mb-0"></h5>
                </div>
                <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                  <a onclick="return confirm('Are you sure to remove cart')" href="<?php echo e(route('removeitems', ['id'=>$cart['id']])); ?>" class="btn btn-danger">remove<i class="fas fa-trash fa-lg"></i></a>
                </div>
               
              </div>
            </div>

          </div>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <div class="alert alert-info">
            no items in your cart
          </div>

          <?php endif; ?>
          <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
            <p class="mb-0"> Total Amount: </p>
          </div>
          <div class="card">
            <div class="card-body">
                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">checkout </a>
            </div>
          </div>
  
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/cart.blade.php ENDPATH**/ ?>