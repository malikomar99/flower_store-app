<?php $show_menu = false;  ?>

<?php if (isset($component)) { $__componentOriginala279b5f84d21bd2f44ccbbbc43457410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala279b5f84d21bd2f44ccbbbc43457410 = $attributes; } ?>
<?php $component = App\View\Components\Navbar1::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala279b5f84d21bd2f44ccbbbc43457410)): ?>
<?php $attributes = $__attributesOriginala279b5f84d21bd2f44ccbbbc43457410; ?>
<?php unset($__attributesOriginala279b5f84d21bd2f44ccbbbc43457410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala279b5f84d21bd2f44ccbbbc43457410)): ?>
<?php $component = $__componentOriginala279b5f84d21bd2f44ccbbbc43457410; ?>
<?php unset($__componentOriginala279b5f84d21bd2f44ccbbbc43457410); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="col-md-12">
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger"><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<form action="<?php echo e(route('addproduct')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleFormControlFile1">Example file input</label>
      <input type="file" class="form-control-file" id="exampleFormControlFile1" name="images">
     
    </div>
          <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">title</label>

        <input type="text" class="form-control" id="title" aria-describedby="emailHelp" name="title" value="<?php echo e(old('title')); ?>">
    </div>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">description</label>

        <input type="text" class="form-control" id="description" aria-describedby="emailHelp" name="description" value="<?php echo e(old('description')); ?>">
    </div>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">quantity</label>

        <input type="text" class="form-control" id="quantity" aria-describedby="emailHelp" name="quantity" value="<?php echo e(old('quantity')); ?>">
    </div>
    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">price</label>

        <input type="text" class="form-control" id="price" aria-describedby="emailHelp" name="price" value="<?php echo e(old('price')); ?>">
    </div>
    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="d-flex justify-content-center">
        <button type="submit" class="btn btn-primary">
          submit
        </button>
    </div>

  </form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/addproduct.blade.php ENDPATH**/ ?>