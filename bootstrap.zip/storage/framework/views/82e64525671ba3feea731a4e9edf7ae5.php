

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('addproduct')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleFormControlFile1">Example file input</label>
      <input type="file" class="form-control-file" id="exampleFormControlFile1">
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">title</label>

        <input type="text" class="form-control" id="title" aria-describedby="emailHelp" name="title" value="">
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">description</label>

        <input type="text" class="form-control" id="description" aria-describedby="emailHelp" name="description" value="">
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">quantity</label>

        <input type="text" class="form-control" id="quantity" aria-describedby="emailHelp" name="quantity" value="">
    </div>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">price</label>

        <input type="text" class="form-control" id="price" aria-describedby="emailHelp" name="price" value="">
    </div>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views//addproduct.blade.php ENDPATH**/ ?>