<?php if (isset($component)) { $__componentOriginal63d8da7f31f1b3a971b8ee798a717883 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal63d8da7f31f1b3a971b8ee798a717883 = $attributes; } ?>
<?php $component = App\View\Components\Adminnavbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminnavbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminnavbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal63d8da7f31f1b3a971b8ee798a717883)): ?>
<?php $attributes = $__attributesOriginal63d8da7f31f1b3a971b8ee798a717883; ?>
<?php unset($__attributesOriginal63d8da7f31f1b3a971b8ee798a717883); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal63d8da7f31f1b3a971b8ee798a717883)): ?>
<?php $component = $__componentOriginal63d8da7f31f1b3a971b8ee798a717883; ?>
<?php unset($__componentOriginal63d8da7f31f1b3a971b8ee798a717883); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(Session::has('massage')): ?>
  <div class="alert alert-success">
    <?php echo e(session::get('massage')); ?>

  </div>
    
  <?php endif; ?>
 
    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card">
                <img src="<?php echo e($pro->images); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($pro->title); ?> </h5>
                  <p class="card-text"><?php echo e($pro->description); ?></p>
                  <p class="card-text">price:<?php echo e($pro->price); ?></p>
                  <p class="card-text">quantity:<?php echo e($pro->quantity); ?></p>
                  
                  <a href="<?php echo e(route('product-details',['id'=>$pro->id])); ?>" class="btn btn-primary">view details </a>
                   <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Buy Now </a>
                  
                  

                </div>
              </div>
        </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views//index.blade.php ENDPATH**/ ?>