<div class="row">
    <div class="col-md-12">
<div class="table-responsive small">
    <table class="table table-striped table-sm table table-dark table-striped">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">firstname</th>
          <th scope="col">lastname</th>
          <th scope="col">Email</th>
          <th scope="col">adress</th>
          <th scope="col">phoneno</th>
          <th scope="col">country</th>
          <th scope="col">state</th>
          <th scope="col">zipcode</th>
          <th scope="col">userid</th>

      
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($u->id); ?></td>
          <td><?php echo e($u->firstname); ?></td>
          <td><?php echo e($u->lastname); ?></td>
          <td><?php echo e($u->email); ?></td>
          <td><?php echo e($u->adress); ?></td>
          <td><?php echo e($u->phoneno); ?></td>
          <td><?php echo e($u->country); ?></td>
          <td><?php echo e($u->state); ?></td>
          <td><?php echo e($u->zipcode); ?></td>
          <td><?php echo e($u->userid); ?></td>
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
</div><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/admin/customer.blade.php ENDPATH**/ ?>