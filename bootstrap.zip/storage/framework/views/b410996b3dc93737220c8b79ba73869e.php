<div class="col-md-3">
<div class="table-responsive small">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Action</th>
      
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($u->id); ?></td>
          <td><?php echo e($u->firstname); ?></td>
          <td><?php echo e($u->email); ?></td>
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/admin/order.blade.php ENDPATH**/ ?>